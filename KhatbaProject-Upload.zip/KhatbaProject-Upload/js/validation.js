// ========== التحقق من نموذج التسجيل ==========
$(document).ready(function () {

    $("#registerForm").on("submit", function (e) {
        e.preventDefault();

        let isValid = true;
        $(".error-msg").text("");

        // 1. الاسم
        const fullname = $("#fullname").val().trim();
        if (fullname.length < 3) {
            $("#err-fullname").text("الاسم يجب أن يكون 3 أحرف على الأقل");
            isValid = false;
        }

        // 2. البريد
        const email = $("#email").val().trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $("#err-email").text("البريد الإلكتروني غير صحيح");
            isValid = false;
        }

        // 3. كلمة المرور
        const password = $("#password").val();
        if (password.length < 6) {
            $("#err-password").text("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
            isValid = false;
        }

        // 4. تأكيد كلمة المرور
        const confirm = $("#confirm").val();
        if (confirm !== password) {
            $("#err-confirm").text("كلمتا المرور غير متطابقتين");
            isValid = false;
        }

        // 5. العمر
        const age = parseInt($("#age").val());
        if (isNaN(age) || age < 18 || age > 80) {
            $("#err-age").text("العمر يجب أن يكون بين 18 و 80");
            isValid = false;
        }

        // 6. الجنس
        const gender = $("#gender").val();
        if (gender === "") {
            $("#err-gender").text("الرجاء اختيار الجنس");
            isValid = false;
        }

        // 7. المدينة
        const city = $("#city").val().trim();
        if (city.length < 2) {
            $("#err-city").text("الرجاء إدخال اسم المدينة");
            isValid = false;
        }

        // النتيجة
        if (isValid) {
            showToast("تم إنشاء الحساب بنجاح! ✅", "success");
            $("#registerForm")[0].reset();
        } else {
            showToast("يوجد أخطاء في النموذج، تحقق منها ⚠️", "error");
        }
    });
});

// ========== دالة Toast ==========
function showToast(message, type) {
    // إزالة أي Toast قديم
    $(".custom-toast").remove();

    const bgColor = (type === "success") ? "#27ae60" : "#e74c3c";

    const toast = $('<div class="custom-toast"></div>')
        .css("background", bgColor)
        .text(message);

    $("body").append(toast);

    // إظهار
    setTimeout(function () { toast.addClass("show"); }, 100);

    // إخفاء بعد 3 ثواني
    setTimeout(function () {
        toast.removeClass("show");
        setTimeout(function () { toast.remove(); }, 500);
    }, 3000);
}
// ========== التحقق من نموذج تسجيل الدخول ==========
$(document).ready(function () {

    $("#loginForm").on("submit", function (e) {
        e.preventDefault();

        let isValid = true;
        $(".error-msg").text("");

        // البريد
        const email = $("#loginEmail").val().trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $("#err-loginEmail").text("البريد الإلكتروني غير صحيح");
            isValid = false;
        }

        // كلمة المرور
        const password = $("#loginPassword").val();
        if (password.length < 6) {
            $("#err-loginPassword").text("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
            isValid = false;
        }

        // النتيجة
        if (isValid) {
            showToast("تم تسجيل الدخول بنجاح! ✅", "success");
            setTimeout(function() {
                window.location.href = "browse.html";
            }, 1500);
        } else {
            showToast("تأكد من البيانات المدخلة ⚠️", "error");
        }
    });
});
// ========== Modal - عرض تفاصيل الملف ==========
$(document).ready(function () {

    $(".view-btn").on("click", function () {
        // جلب البيانات
        const name = $(this).data("name");
        const age = $(this).data("age");
        const city = $(this).data("city");
        const specs = $(this).data("specs");

        // وضعها في Modal
        $("#modalName").text(name);
        $("#modalAge").text(age + " سنة");
        $("#modalCity").text(city);
        $("#modalSpecs").text(specs);

        // فتح Modal
        const modal = new bootstrap.Modal(document.getElementById('profileModal'));
        modal.show();
    });

    // زر طلب التواصل
    $("#contactBtn").on("click", function () {
        // إغلاق Modal
        bootstrap.Modal.getInstance(document.getElementById('profileModal')).hide();
        
        // Toast
        showToast("تم إرسال طلب التواصل، سيتم مراجعته ✅", "success");
    });
});
// ========== نموذج التواصل ==========
$(document).ready(function () {

    $("#contactForm").on("submit", function (e) {
        e.preventDefault();

        let isValid = true;
        $(".error-msg").text("");

        // الاسم
        const name = $("#contactName").val().trim();
        if (name.length < 3) {
            $("#err-contactName").text("الاسم يجب أن يكون 3 أحرف على الأقل");
            isValid = false;
        }

        // البريد
        const email = $("#contactEmail").val().trim();
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $("#err-contactEmail").text("البريد الإلكتروني غير صحيح");
            isValid = false;
        }

        // الرسالة
        const message = $("#contactMessage").val().trim();
        if (message.length < 10) {
            $("#err-contactMessage").text("الرسالة يجب أن تكون 10 أحرف على الأقل");
            isValid = false;
        }

        // النتيجة
        if (isValid) {
            showToast("تم إرسال رسالتك بنجاح! سنرد عليك قريباً ✅", "success");
            $("#contactForm")[0].reset();
        } else {
            showToast("تأكد من البيانات المدخلة ⚠️", "error");
        }
    });
});
